# -*- coding: utf-8 -*-
"""extend_oled.py — 【已弃用, 请勿运行】历史 oled.h/oled.c 追加脚本, 仅留档。
   当前宏定义以工程内 HARDWARE/OLED/oled.h 为准(CH_LIU=22 刘, CH_JIA=23 嘉, CH_CHEN=25 宸)。
向 oled.h / oled.c 追加汉字索引、硬件滚动与帧缓冲代码（保持 GBK）"""
import os

base = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'

# ---------------- oled.h 追加 ----------------
h_add = u"""
//-----------------汉字点阵索引(对应 oledfont.h 中 Hzk 表)----------------
#define CH_XUE      0   //学
#define CH_HAO      1   //号
#define CH_XING     2   //姓
#define CH_MING     3   //名
#define CH_WEN      4   //温
#define CH_DU       5   //度
#define CH_HUMID    6   //湿
#define CH_HUAN     7   //欢
#define CH_YING     8   //迎
#define CH_LAI      9   //来
#define CH_DAO      10  //到
#define CH_CHONG    11  //重
#define CH_QING     12  //庆
#define CH_JIAO     13  //交
#define CH_TONG     14  //通
#define CH_DA       15  //大
#define CH_WU       16  //物
#define CH_LIAN     17  //联
#define CH_WANG     18  //网
#define CH_SHI      19  //实
#define CH_XUN      20  //训
#define CH_ROOM     21  //室
#define CH_LIU     22  //刘
#define CH_JIA     23  //嘉
#define CH_CELSIUS  24  //℃
#define CH_CHEN     25  //宸

//-----------------SSD1306 硬件滚动 & 软件帧缓冲----------------
void OLED_Scroll_Stop(void);
void OLED_Scroll_Horizontal(u8 dir, u8 start_page, u8 end_page, u8 interval);
void OLED_Scroll_Vertical(u8 dir, u8 start_page, u8 end_page, u8 interval, u8 fixed_rows, u8 scroll_rows);
void OLED_FB_Clear(void);
void OLED_FB_Flush(void);
void OLED_FB_ShowChar(s16 x, u8 y, u8 chr, u8 Char_Size);
void OLED_FB_ShowCHinese(s16 x, u8 y, u8 no);

#endif  """

h_path = os.path.join(base, 'HARDWARE', 'OLED', 'oled.h')
raw = open(h_path, 'rb').read().decode('gbk')
assert raw.rstrip().endswith('#endif')
idx = raw.rindex('#endif')
raw = raw[:idx] + h_add + '\n'
open(h_path, 'wb').write(raw.encode('gbk'))
print('oled.h extended:', len(raw.encode('gbk')), 'bytes')

# ---------------- oled.c 追加 ----------------
c_add = u"""
/* ==================== SSD1306 硬件滚动 ====================
 * 说明: SSD1306 的硬件滚动只移动显示窗口, 不改变 GDDRAM 内容,
 *       内容在滚动区内循环(从一侧移出后从另一侧移入), 由硬件自动完成。
 */
/* 停止硬件滚动 */
void OLED_Scroll_Stop(void)
{
    OLED_WR_Byte(0x2E, OLED_CMD);
}
/* 水平滚动: dir=0 左移, dir=1 右移; start_page/end_page 0~7; interval 帧间隔 */
void OLED_Scroll_Horizontal(u8 dir, u8 start_page, u8 end_page, u8 interval)
{
    OLED_Scroll_Stop();                     /* 先停止旧滚动 */
    OLED_WR_Byte(dir ? 0x26 : 0x27, OLED_CMD);  /* 26h 右移, 27h 左移 */
    OLED_WR_Byte(0x00, OLED_CMD);           /* 虚拟字节 */
    OLED_WR_Byte(start_page, OLED_CMD);     /* 起始页 */
    OLED_WR_Byte(interval, OLED_CMD);       /* 滚动速度 */
    OLED_WR_Byte(end_page, OLED_CMD);       /* 结束页 */
    OLED_WR_Byte(0x00, OLED_CMD);           /* 虚拟字节 */
    OLED_WR_Byte(0xFF, OLED_CMD);           /* 虚拟字节 */
    OLED_WR_Byte(0x2F, OLED_CMD);           /* 开启滚动 */
}
/* 垂直+水平滚动: dir=0 左上, dir=1 右上; fixed_rows 顶部固定行, scroll_rows 滚动区行数 */
void OLED_Scroll_Vertical(u8 dir, u8 start_page, u8 end_page, u8 interval, u8 fixed_rows, u8 scroll_rows)
{
    OLED_Scroll_Stop();
    OLED_WR_Byte(0xA3, OLED_CMD);           /* 设置垂直滚动区域 */
    OLED_WR_Byte(fixed_rows, OLED_CMD);     /* 顶部固定行数 */
    OLED_WR_Byte(scroll_rows, OLED_CMD);    /* 滚动区行数 */
    OLED_WR_Byte(dir ? 0x29 : 0x2A, OLED_CMD);  /* 29h 右+上滚, 2Ah 左+上滚 */
    OLED_WR_Byte(0x00, OLED_CMD);           /* 虚拟字节 */
    OLED_WR_Byte(start_page, OLED_CMD);
    OLED_WR_Byte(interval, OLED_CMD);
    OLED_WR_Byte(end_page, OLED_CMD);
    OLED_WR_Byte(0x00, OLED_CMD);
    OLED_WR_Byte(0xFF, OLED_CMD);
    OLED_WR_Byte(0x2F, OLED_CMD);           /* 开启滚动 */
}

/* ==================== 软件帧缓冲 (用于平滑跑马灯) ====================
 * g_fb[8][128] 对应 8 页 x 128 列, 在内存中整幅绘制后一次性刷新,
 * 实现任意像素级偏移的长文本平滑左移。
 */
static u8 g_fb[8][128];

void OLED_FB_Clear(void)
{
    u16 i;
    u8 *p = (u8 *)g_fb;
    for (i = 0; i < 8 * 128; i++) p[i] = 0;
}

/* 将帧缓冲整体刷到 OLED (每页一条连续 IIC 写, 速度快) */
void OLED_FB_Flush(void)
{
    u8 p, n;
    for (p = 0; p < 8; p++)
    {
        OLED_WR_Byte(0xB0 + p, OLED_CMD);   /* 页地址 */
        OLED_WR_Byte(0x00, OLED_CMD);       /* 列地址低 */
        OLED_WR_Byte(0x10, OLED_CMD);       /* 列地址高 */
        IIC_Start();
        Write_IIC_Byte(0x78);               /* 从机地址(写) */
        IIC_Wait_Ack();
        Write_IIC_Byte(0x40);               /* 连续数据模式 */
        IIC_Wait_Ack();
        for (n = 0; n < 128; n++)
        {
            Write_IIC_Byte(g_fb[p][n]);
            IIC_Wait_Ack();
        }
        IIC_Stop();
    }
}

/* 向帧缓冲画 ASCII 字符 (带左右裁剪, x 可为负), 16 号字 8x16 / 12 号字 6x8 */
void OLED_FB_ShowChar(s16 x, u8 y, u8 chr, u8 Char_Size)
{
    u8 i, c;
    s16 cx;
    c = chr - ' ';                          /* 得到偏移后的索引 */
    if (y > 63) return;
    if (Char_Size == 16)
    {
        if (y + 16 > 64) return;
        for (i = 0; i < 8; i++)
        {
            cx = x + i;
            if (cx < 0 || cx > 127) continue;
            g_fb[y >> 3][cx]     = F8X16[c * 16 + i];
            g_fb[(y >> 3) + 1][cx] = F8X16[c * 16 + i + 8];
        }
    }
    else
    {
        if (y + 8 > 64) return;
        for (i = 0; i < 6; i++)
        {
            cx = x + i;
            if (cx < 0 || cx > 127) continue;
            g_fb[y >> 3][cx] = F6x8[c][i];
        }
    }
}

/* 向帧缓冲画 16x16 汉字 (带左右裁剪, x 可为负) */
void OLED_FB_ShowCHinese(s16 x, u8 y, u8 no)
{
    u8 i;
    s16 cx;
    if (y > 63) return;
    if (y + 16 > 64) return;
    for (i = 0; i < 16; i++)
    {
        cx = x + i;
        if (cx < 0 || cx > 127) continue;
        g_fb[y >> 3][cx]     = Hzk[2 * no][i];
        g_fb[(y >> 3) + 1][cx] = Hzk[2 * no + 1][i];
    }
}
"""

c_path = os.path.join(base, 'HARDWARE', 'OLED', 'oled.c')
raw = open(c_path, 'rb').read().decode('gbk')
raw = raw.rstrip() + '\n' + c_add
open(c_path, 'wb').write(raw.encode('gbk'))
print('oled.c extended:', len(raw.encode('gbk')), 'bytes')
