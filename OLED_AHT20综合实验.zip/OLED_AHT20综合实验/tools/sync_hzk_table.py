# -*- coding: utf-8 -*-
"""sync_hzk_table.py — 用工程 oledfont.h 中当前 Hzk 段刷新 tools/Hzk_table.h 缓存(GBK)。
工程实际使用 oledfont.h; 本脚本仅让 tools 目录留档缓存与工程保持一致。
"""
import os, re

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
hz_path = os.path.join(BASE, 'HARDWARE', 'OLED', 'oledfont.h')
tbl_path = os.path.join(BASE, 'tools', 'Hzk_table.h')

hz = open(hz_path, 'rb').read().decode('gbk')
m = re.search(r'(?s)const unsigned char Hzk\[\]\[32\]\s*=\s*\{.*?\};', hz)
assert m, 'Hzk segment not found in oledfont.h'
seg = m.group(0)

header = (
    '// Hzk_table.h — 26 个汉字 16x16 纵向点阵 (厂商兼容布局: 每字 2 行 x 16 字节)\r\n'
    '// 来源: 与工程 HARDWARE/OLED/oledfont.h 中 Hzk 段保持一致 (由 apply_name_change.py 维护)\r\n'
    '// 字符顺序: 学号姓名 温湿度 欢迎来到重庆交通大学物联网实训室 刘 嘉 ℃ 宸\r\n'
    '// 行索引: Hzk[2*no] = 上半 16 列, Hzk[2*no+1] = 下半 16 列, 声明 Hzk[][32] 余位自动补 0\r\n'
)
open(tbl_path, 'wb').write((header + seg + '\r\n').encode('gbk'))
print('Hzk_table.h synced, chars=26')
