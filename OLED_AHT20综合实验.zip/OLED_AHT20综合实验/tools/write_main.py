# -*- coding: utf-8 -*-
"""write_main.py — 【已弃用, 请勿运行】历史 main.c 生成脚本。
   当前 USER/main.c 以 Keil 工程内版本为准(含 IIC 自测屏、ShowHex、垂直滚动等),
   本脚本仅留档; 姓名=刘嘉宸, 学号=632407030219 已与工程核对一致。
"""
import os

base = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
main_c = u"""//////////////////////////////////////////////////////////////////////////////////
// 文件名: main.c
// 说明  : OLED(SSD1306, IIC) + AHT20 温湿度综合显示实验 (STM32F103C8)
// 功能  : 1) 显示学号与姓名
//         2) 显示 AHT20 温度与湿度
//         3) 长文本滑动显示(硬件水平/垂直滚动 + 软件跑马灯)
// 接线  : OLED  SCL=PA5  SDA=PA7  (3.3V)
//         AHT20 SCL=PB6  SDA=PB7  (3.3V)
//////////////////////////////////////////////////////////////////////////////////

#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "aht20.h"

/* 长文本: "Hello, 欢迎来到重庆交通大学物联网205实训室!" */
#define MARQUEE_ASCII_LEN   7                /* "Hello, " 7 个字符, 56px */
#define MARQUEE_CN_LEN      16               /* 16 个汉字, 256px */
#define MARQUEE_TAIL_LEN    4                /* "205!" 4 个字符, 32px */
#define MARQUEE_WIDTH       (56 + 256 + 32)  /* 文本总宽 344px */

void OLED_ShowFloat(u8 x, u8 y, float f, u8 int_len, u8 dec_len, u8 size);
void OLED_Marquee_Draw(s16 x, u8 y);

int main(void)
{
    u8   k, err;
    float temp = 0, humi = 0;
    s16  xoff;

    delay_init();               /* 延时初始化 */
    NVIC_Configuration();       /* NVIC 中断分组 */
    OLED_Init();                /* OLED 初始化 */
    OLED_Clear();               /* 清屏 */
    AHT20_Init();               /* AHT20 初始化 */

    while (1)
    {
        /* ========== 第 1 屏: 学号 + 姓名 ========== */
        OLED_Clear();
        OLED_ShowCHinese(0, 0, CH_XUE);            /* 学 */
        OLED_ShowCHinese(16, 0, CH_HAO);           /* 号 */
        OLED_ShowString(32, 0, "632407030219", 16);/* 学号 */
        OLED_ShowCHinese(28, 2, CH_XING);          /* 姓 */
        OLED_ShowCHinese(44, 2, CH_MING);          /* 名 */
        OLED_ShowChar(60, 2, ':', 16);
        OLED_ShowCHinese(68, 2, CH_LIU);          /* 刘 */
        OLED_ShowCHinese(84, 2, CH_JIA);          /* 嘉 */
        OLED_ShowCHinese(100, 2, CH_CHEN);         /* 宸 */
        OLED_ShowString(8, 4, "0.96 OLED DEMO", 16);
        delay_ms(3000);

        /* ========== 第 2 屏: AHT20 温湿度 (每秒刷新) ========== */
        for (k = 0; k < 8; k++)
        {
            OLED_Clear();
            err = AHT20_Read_Temp_Humi(&temp, &humi);

            /* 温度: 温度:xx.x℃ */
            OLED_ShowCHinese(16, 0, CH_WEN);
            OLED_ShowCHinese(32, 0, CH_DU);
            OLED_ShowChar(48, 0, ':', 16);
            if (err == 0)
            {
                OLED_ShowFloat(56, 0, temp, 2, 1, 16);
                OLED_ShowCHinese(88, 0, CH_CELSIUS);   /* ℃ */
            }
            else OLED_ShowString(56, 0, "ERROR", 16);

            /* 湿度: 湿度:xx.x% */
            OLED_ShowCHinese(16, 2, CH_HUMID);
            OLED_ShowCHinese(32, 2, CH_DU);
            OLED_ShowChar(48, 2, ':', 16);
            if (err == 0)
            {
                OLED_ShowFloat(56, 2, humi, 2, 1, 16);
                OLED_ShowChar(88, 2, '%', 16);
            }
            else OLED_ShowString(56, 2, "ERROR", 16);

            OLED_ShowString(16, 4, "AHT20 SENSOR", 16);
            OLED_ShowString(20, 6, "IIC PB6-PB7", 16);
            delay_ms(1000);
        }

        /* ========== 第 3 屏: 硬件水平滚动 (左右滑动) ========== */
        OLED_Clear();
        /* 第 1 行: Hello,欢迎来到 */
        OLED_ShowString(0, 0, "Hello,", 16);
        OLED_ShowCHinese(48, 0, CH_HUAN);   /* 欢 */
        OLED_ShowCHinese(64, 0, CH_YING);   /* 迎 */
        OLED_ShowCHinese(80, 0, CH_LAI);    /* 来 */
        OLED_ShowCHinese(96, 0, CH_DAO);    /* 到 */
        /* 第 2 行: 重庆交通大学 */
        OLED_ShowCHinese(0, 2, CH_CHONG);   /* 重 */
        OLED_ShowCHinese(16, 2, CH_QING);   /* 庆 */
        OLED_ShowCHinese(32, 2, CH_JIAO);   /* 交 */
        OLED_ShowCHinese(48, 2, CH_TONG);   /* 通 */
        OLED_ShowCHinese(64, 2, CH_DA);     /* 大 */
        OLED_ShowCHinese(80, 2, CH_XUE);    /* 学 */
        /* 第 3 行: 物联网205实训 */
        OLED_ShowCHinese(0, 4, CH_WU);      /* 物 */
        OLED_ShowCHinese(16, 4, CH_LIAN);   /* 联 */
        OLED_ShowCHinese(32, 4, CH_WANG);   /* 网 */
        OLED_ShowString(48, 4, "205", 16);
        OLED_ShowCHinese(72, 4, CH_SHI);    /* 实 */
        OLED_ShowCHinese(88, 4, CH_XUN);    /* 训 */
        /* 第 4 行: 室!AHT20 DEMO */
        OLED_ShowCHinese(0, 6, CH_ROOM);    /* 室 */
        OLED_ShowChar(16, 6, '!', 16);
        OLED_ShowString(24, 6, "AHT20 DEMO", 16);

        OLED_Scroll_Horizontal(0, 0, 7, 0x00);  /* 硬件水平左移, 全页, 5 帧间隔 */
        delay_ms(5000);
        OLED_Scroll_Stop();                     /* 停止滚动 */

        /* ========== 第 4 屏: 硬件垂直+水平滚动 (上下滑动) ========== */
        OLED_Scroll_Vertical(1, 0, 7, 0x00, 0, 64); /* 右上方向, 全区 64 行 */
        delay_ms(5000);
        OLED_Scroll_Stop();

        /* ========== 第 5 屏: 软件跑马灯 (完整长文本平滑左移) ========== */
        for (xoff = 0; xoff <= (s16)(MARQUEE_WIDTH - 128); xoff += 4)
        {
            OLED_FB_Clear();
            OLED_Marquee_Draw(-xoff, 2);        /* 画在第 2 行(16~31 行), 垂直居中 */
            OLED_FB_Flush();                    /* 整屏刷新 */
            delay_ms(20);
        }
        delay_ms(1500);
    }
}

/* 带符号小数显示: -12.3 / 25.3 等 */
void OLED_ShowFloat(u8 x, u8 y, float f, u8 int_len, u8 dec_len, u8 size)
{
    u32 ip, dp;

    if (f < 0) { OLED_ShowChar(x, y, '-', size); x += size / 2; f = -f; }
    ip = (u32)f;
    dp = (u32)((f - ip) * 10.0f + 0.5f);        /* 保留 1 位小数, 四舍五入 */

    OLED_ShowNum(x, y, ip, int_len, size);
    x += int_len * (size / 2);
    OLED_ShowChar(x, y, '.', size);
    x += size / 2;
    OLED_ShowNum(x, y, dp, dec_len, size);
}

/* 在帧缓冲中按像素偏移 x 绘制整行长文本 (自动左右裁剪) */
void OLED_Marquee_Draw(s16 x, u8 y)
{
    u8 i;
    s16 xx = x;
    const u8 ascii[MARQUEE_ASCII_LEN] = {'H', 'e', 'l', 'l', 'o', ',', ' '};
    const u8 cn[MARQUEE_CN_LEN] = {CH_HUAN, CH_YING, CH_LAI, CH_DAO,
                                   CH_CHONG, CH_QING, CH_JIAO, CH_TONG,
                                   CH_DA, CH_XUE, CH_WU, CH_LIAN,
                                   CH_WANG, CH_SHI, CH_XUN, CH_ROOM};
    const u8 tail[MARQUEE_TAIL_LEN] = {'2', '0', '5', '!'};

    for (i = 0; i < MARQUEE_ASCII_LEN; i++) { OLED_FB_ShowChar(xx, y, ascii[i], 16); xx += 8; }
    for (i = 0; i < MARQUEE_CN_LEN; i++)    { OLED_FB_ShowCHinese(xx, y, cn[i]); xx += 16; }
    for (i = 0; i < MARQUEE_TAIL_LEN; i++)  { OLED_FB_ShowChar(xx, y, tail[i], 16); xx += 8; }
}
"""

path = os.path.join(base, 'USER', 'main.c')
open(path, 'wb').write(main_c.encode('gbk'))
print('main.c written, bytes:', len(main_c.encode('gbk')))
