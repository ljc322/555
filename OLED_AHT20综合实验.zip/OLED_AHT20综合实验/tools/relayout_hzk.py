# -*- coding: utf-8 -*-
"""relayout_hzk.py — 【已弃用, 请勿运行】历史字库重排脚本, 仅留档。
   当前 Hzk 字库以工程内 HARDWARE/OLED/oledfont.h 为准(共 26 字, 含刘/嘉/宸)。
将 Hzk 从 26 行x32 字节 重排为厂商兼容布局:
   每字 2 行 x 16 字节 (行 2*no=上半 16 列, 行 2*no+1=下半 16 列),
   声明仍为 Hzk[][32] (每行余 16 字节自动补 0), 与 OLED_ShowCHinese 的
   Hzk[2*no][t] / Hzk[2*no+1][t] (t<16) 访问方式一致。
"""
import os, re

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
FONT = os.path.join(BASE, 'HARDWARE', 'OLED', 'oledfont.h')

text = open(FONT, 'rb').read().decode('gbk', errors='replace')

# 1) 解析现有 25 行 x 32 字节数据
def strip_c(s):
    s = re.sub(r'//[^\r\n]*', '', s)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    return s

st = strip_c(text)
i = st.find('Hzk')
i = st.index('{', i)
depth = 0; j = i
while j < len(st):
    if st[j] == '{': depth += 1
    elif st[j] == '}':
        depth -= 1
        if depth == 0: break
    j += 1
body = st[i+1:j]
toks = [int(x, 16) for x in re.findall(r'0[xX][0-9A-Fa-f]+', body)]
assert len(toks) == 26 * 32, 'unexpected token count: %d' % len(toks)
chars = [toks[k*32:(k+1)*32] for k in range(26)]

# 2) 取字符标签 (从原始文本注释 /*"字"*/ 提取, 按出现顺序)
labels = re.findall(r'/\*"([^"]+)"', text[text.find('Hzk'):])
assert len(labels) == 26, 'labels: %d' % len(labels)

# 3) 生成厂商布局 Hzk 段
lines = ['const unsigned char Hzk[][32] = {']
for no, (c, lab) in enumerate(zip(chars, labels)):
    up = c[0:16]
    dn = c[16:32]
    lines.append('    {%s},/*"%s",%d*/' % (','.join('0x%02X' % b for b in up), lab, no))
    lines.append('    {%s},' % (','.join('0x%02X' % b for b in dn)))
lines.append('};')
new_hzk = '\r\n'.join(lines) + '\r\n'

# 4) 替换工程 oledfont.h 中的 Hzk 段 (声明行起点 -> 括号配平终点)
decl_start = text.find('const unsigned char Hzk[][32] = {')
assert decl_start >= 0, 'Hzk declaration not found'
# 在原始文本上做括号配平 (先剥离注释避免干扰, 用映射回原始位置)
st2 = strip_c(text)
k = st2.find('const unsigned char Hzk[][32] = {')
k = st2.index('{', k)
depth = 0; e = k
while e < len(st2):
    if st2[e] == '{': depth += 1
    elif st2[e] == '}':
        depth -= 1
        if depth == 0: break
    e += 1
# 找到原始文本中与该位置对应的 ';' 结束 (Hzk 段结束于 '};')
end_marker = text.find('};', decl_start)
assert end_marker >= 0
sec_end = end_marker + 2
text2 = text[:decl_start] + new_hzk + text[sec_end:]

# 5) 写回 (GBK)
open(FONT, 'wb').write(text2.encode('gbk'))
print('oledfont.h updated: %d chars, layout 2x16' % len(chars))

# 6) 同步更新 tools/Hzk_table.h
tbl = os.path.join(BASE, 'tools', 'Hzk_table.h')
header = '''// Hzk_table.h — 26 个汉字 16x16 纵向点阵 (厂商兼容布局: 每字 2 行 x 16 字节)
// 生成: tools/relayout_hzk.py (数据源自 font_gen.py 的 32 字节主表)
// 字符顺序: 学号姓名(学号姓名) 温湿度(温度湿度) 滚动文本(欢迎来到重庆交通大学物联网实训室) 刘嘉宸 ℃
// 行索引: Hzk[2*no]   = 上半 16 列, Hzk[2*no+1] = 下半 16 列, 声明 Hzk[][32] 余位自动补 0
'''
open(tbl, 'w', encoding='gbk').write(header + new_hzk.replace('\r\n', '\n'))
print('tools/Hzk_table.h updated')
