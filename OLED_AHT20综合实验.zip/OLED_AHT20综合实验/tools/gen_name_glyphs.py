# -*- coding: utf-8 -*-
"""gen_name_glyphs.py — 为新姓名"刘嘉宸"生成 16x16 纵向点阵, 规则与 font_gen.py 一致。
先 dry-run: 打印 32 字节/字, 并把新字与旧字(陈/桦)并排渲染成预览图供人工核对。
布局: 上半 16 列(rows0-7) + 下半 16 列(rows8-15), 每列一字节, bit0=页内最上行。
"""
import os, re
from PIL import Image, ImageDraw, ImageFont

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
FONT_PATH = r'C:\Windows\Fonts\simhei.ttf'
SIZE = 16
NEW_CHARS = ['刘', '嘉', '宸']

font = ImageFont.truetype(FONT_PATH, SIZE)

def char_bitmap(ch):
    img = Image.new('L', (SIZE, SIZE), 0)
    ImageDraw.Draw(img).text((0, 0), ch, font=font, fill=255)
    px = img.load()
    rows = []
    for y in range(SIZE):
        rows.append([1 if px[x, y] > 127 else 0 for x in range(SIZE)])
    return rows

def rows_to_bytes(rows):
    out = []
    for half in (0, 1):
        for c in range(16):
            b = 0
            for r in range(8):
                if rows[half * 8 + r][c]:
                    b |= (1 << r)
            out.append(b)
    return out

def bytes_to_rows(byts):
    r = [[0] * 16 for _ in range(16)]
    for c in range(16):
        bt, bb = byts[c], byts[16 + c]
        for rr in range(8):
            if bt & (1 << rr):
                r[rr][c] = 1
            if bb & (1 << rr):
                r[8 + rr][c] = 1
    return r

new_data = {}
for ch in NEW_CHARS:
    rows = char_bitmap(ch)
    n = sum(sum(x) for x in rows)
    byts = rows_to_bytes(rows)
    new_data[ch] = byts
    print('=== %s  pixels=%d ===' % (ch, n))
    print(' up: ' + ','.join('0x%02X' % b for b in byts[0:16]))
    print(' dn: ' + ','.join('0x%02X' % b for b in byts[16:32]))

# 解析现有 oledfont.h 中旧 22 陈 / 23 桦 点阵, 用于并排对照
hz_path = os.path.join(BASE, 'HARDWARE', 'OLED', 'oledfont.h')
hz_text = open(hz_path, 'rb').read().decode('gbk', errors='replace')
m = re.search(r'(?s)const unsigned char Hzk\[\]\[32\]\s*=\s*\{(.*?)\};', hz_text)
rows_txt = re.findall(r'\{([0-9A-Fa-fx,]+)\}', m.group(1))
def row_bytes(i):
    return [int(x, 16) for x in rows_txt[i].split(',')]
old = {}
for label, up_i, dn_i in [('陈', 44, 45), ('桦', 46, 47)]:  # 厂商布局: 字 no=22 -> 行 44/45
    up, dn = row_bytes(up_i), row_bytes(dn_i)
    old[label] = up + dn

# 预览图: 旧陈/旧桦 在前, 新刘/嘉/宸 在后
scale = 6
items = list(old.items()) + list(new_data.items())
cols = len(items)
cell_w = SIZE * scale + 18
cell_h = SIZE * scale + 26
canvas = Image.new('RGB', (cols * cell_w + 8, cell_h + 10), (255, 255, 255))
dc = ImageDraw.Draw(canvas)
for k, (ch, byts) in enumerate(items):
    r = bytes_to_rows(byts)
    cx = 8 + k * cell_w
    cy = 8
    for y in range(16):
        for x in range(16):
            if r[y][x]:
                dc.rectangle([cx + x * scale, cy + y * scale,
                              cx + (x + 1) * scale - 1, cy + (y + 1) * scale - 1],
                             fill=(20, 20, 20))
    tag = ch + ('(旧)' if ch in old else '(新)')
    dc.text((cx, cy + SIZE * scale + 6), tag, fill=(200, 0, 0))
out_png = os.path.join(BASE, 'tools', 'preview_name.png')
canvas.save(out_png)
print('preview:', out_png)
