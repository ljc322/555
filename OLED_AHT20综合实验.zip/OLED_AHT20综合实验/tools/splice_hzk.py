# -*- coding: utf-8 -*-
"""splice_hzk.py — 【已弃用, 请勿运行】历史字库拼接脚本, 仅留档。
   当前 Hzk 字库以工程内 HARDWARE/OLED/oledfont.h 为准。"""
import re, os

base = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
fpath = os.path.join(base, 'HARDWARE', 'OLED', 'oledfont.h')
tbl_path = os.path.join(base, 'tools', 'Hzk_table.h')

tbl = open(tbl_path, encoding='utf-8').read().strip()
raw = open(fpath, 'rb').read()
text = raw.decode('gbk')

pat = re.compile(r'(?s)char\s+Hzk\[\]\[32\]\s*=\s*\{.*?\};')
m = pat.search(text)
print('match:', bool(m))
if m:
    text = text[:m.start()] + tbl + text[m.end():]
    open(fpath, 'wb').write(text.encode('gbk'))
    t2 = open(fpath, 'rb').read().decode('gbk')
    print('spliced ok, file bytes:', len(text.encode('gbk')))
    print('new Hzk entries:', t2.count('/*"'))
