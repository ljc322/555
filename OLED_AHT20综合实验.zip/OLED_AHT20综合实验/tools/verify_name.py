# -*- coding: utf-8 -*-
"""verify_name.py — 静态校验 + 第一屏渲染核对(读取工程真实字库)。
校验: 括号配平 / Hzk 条目尺寸 / main.c 使用宏均已定义 / 索引一致。
渲染: 按 main.c 第一屏真实调用画 128x64 预览图 tools/verify_screen1.png。
"""
import os, re
from PIL import Image

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'

def read(rel, enc):
    return open(os.path.join(BASE, rel), 'rb').read().decode(enc, errors='replace')

main_c = read('USER/main.c', 'utf-8')
oled_h = read('HARDWARE/OLED/oled.h', 'gbk')
oled_c = read('HARDWARE/OLED/oled.c', 'gbk')
hz_h = read('HARDWARE/OLED/oledfont.h', 'gbk')

# ---------- 1. 括号配平 ----------
def strip(text):
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == '/' and i + 1 < n and text[i+1] == '/':
            j = text.find('\n', i); i = j if j != -1 else n
        elif c == '/' and i + 1 < n and text[i+1] == '*':
            j = text.find('*/', i+2); i = j+2 if j != -1 else n
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                if text[i] == '\\': i += 1
                i += 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and text[i] != "'":
                if text[i] == '\\': i += 1
                i += 1
            i += 1
        else:
            out.append(c); i += 1
    return ''.join(out)

print('== 括号配平 ==')
for name, t in [('main.c', main_c), ('oled.c', oled_c), ('oled.h', oled_h), ('oledfont.h', hz_h)]:
    s = strip(t)
    ok = all(s.count(a) == s.count(b) for a, b in [('{','}'),('(',')'),('[',']')])
    print('  %-12s %s' % (name, 'ok' if ok else '!! 不配平'))

# ---------- 2. Hzk 表 ----------
print('\n== Hzk 字库 ==')
m = re.search(r'(?s)const unsigned char Hzk\[\]\[32\]\s*=\s*\{(.*?)\};', hz_h)
body = m.group(1)
rows = re.findall(r'\{([0-9A-Fa-fx,]+)\}', body)
labels = re.findall(r'/\*"([^"]+)",(\d+)\*/', body)
print('  行数:', len(rows), '(期望 52 = 26 字 x 2)')
bad = [i for i, r in enumerate(rows) if len(r.split(',')) != 16]
print('  尺寸异常行:', bad if bad else 'none')
print('  字表:', [(lab, int(idx)) for lab, idx in labels])

# ---------- 3. 宏定义 vs main.c 使用 ----------
print('\n== 宏定义一致性 ==')
defs = dict(re.findall(r'#define\s+(CH_[A-Z0-9_]+)\s+(\d+)', oled_h))
used = set(re.findall(r'\bCH_[A-Z0-9_]+\b', main_c))
missing = used - set(defs)
print('  已定义:', defs)
print('  main.c 使用:', sorted(used))
print('  未定义:', sorted(missing) if missing else 'none')

# 索引一致性: main.c 第一屏姓名宏 -> 字表标签
want = {'CH_LIU': '刘', 'CH_JIA': '嘉', 'CH_CHEN': '宸'}
for macro, char in want.items():
    idx = int(defs[macro])
    lab = labels[idx][0]
    print('  %s = %d  字表标签=%s  %s' % (macro, idx, lab,
          'OK' if lab == char else '!! 应为 ' + char))
# 学号
sid = re.search(r'OLED_ShowString\(32, 0, "(\d+)"', main_c).group(1)
print('  学号:', sid, 'OK' if sid == '632407030219' else '!! 错误')

# ---------- 4. 渲染第一屏 ----------
def parse_array(name, row_len):
    st = strip(hz_h)
    start = st.find(name); i = st.index('{', start)
    depth = 0; j = i
    while j < len(st):
        if st[j] == '{': depth += 1
        elif st[j] == '}':
            depth -= 1
            if depth == 0: break
        j += 1
    toks = [int(x, 16) for x in re.findall(r'0[xX][0-9A-Fa-f]+', st[i+1:j])]
    return [toks[k*row_len:(k+1)*row_len] for k in range(len(toks)//row_len)]

F8X16 = parse_array('F8X16', 16)
Hzk = parse_array('Hzk', 16)

class OLED:
    def __init__(self): self.fb = [[0]*128 for _ in range(8)]
    def char(self, x, y, ch, size=16):
        c = ord(ch) - 32
        row = F8X16[c]
        for i in range(8):
            self.fb[y][x+i] = row[i]; self.fb[y+1][x+i] = row[i+8]
    def sstr(self, x, y, s):
        for ch in s:
            self.char(x, y, ch); x += 8
    def cn(self, x, y, no):
        up, dn = Hzk[2*no], Hzk[2*no+1]
        for i in range(16):
            self.fb[y][x+i] = up[i]; self.fb[y+1][x+i] = dn[i]
    def render(self, scale=4):
        img = Image.new('RGB', (128*scale, 64*scale), (0, 0, 0))
        px = img.load()
        for p in range(8):
            for c in range(128):
                b = self.fb[p][c]
                for r in range(8):
                    if b & (1 << r):
                        for dx in range(scale):
                            for dy in range(scale):
                                px[c*scale+dx, (p*8+r)*scale+dy] = (0, 200, 0)
        return img

o = OLED()
D = defs
o.cn(0, 0, int(D['CH_XUE'])); o.cn(16, 0, int(D['CH_HAO']))
o.sstr(32, 0, sid)
o.cn(28, 2, int(D['CH_XING'])); o.cn(44, 2, int(D['CH_MING']))
o.char(60, 2, ':')
o.cn(68, 2, int(D['CH_LIU'])); o.cn(84, 2, int(D['CH_JIA'])); o.cn(100, 2, int(D['CH_CHEN']))
o.sstr(8, 4, '0.96 OLED DEMO')
out = os.path.join(BASE, 'tools', 'verify_screen1.png')
o.render().save(out)
print('\n  第一屏预览:', out)
