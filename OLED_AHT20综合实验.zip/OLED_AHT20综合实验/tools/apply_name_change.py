# -*- coding: utf-8 -*-
"""apply_name_change.py — 把第一屏姓名改为"刘嘉宸", 学号保持 632407030219。
改动范围:
  1) HARDWARE/OLED/oledfont.h  Hzk 字库: 22=刘, 23=嘉, 24=℃(保留), 25=宸(新增)
  2) HARDWARE/OLED/oled.h      宏: CH_LIU=22, CH_JIA=23, CH_CELSIUS=24, CH_CHEN=25
  3) USER/main.c               姓名三行调用与行尾注释; 学号保持不变
编码: oledfont.h / oled.h 为 GBK, main.c 为 UTF-8; 换行符保持各文件原样。
"""
import os, re
from PIL import Image, ImageDraw, ImageFont

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
FONT_PATH = r'C:\Windows\Fonts\simhei.ttf'
SIZE = 16

# ---------- 1. 生成新字点阵 (规则同 font_gen.py: 纵向取模, 上半16+下半16) ----------
font = ImageFont.truetype(FONT_PATH, SIZE)

def glyph_bytes(ch):
    img = Image.new('L', (SIZE, SIZE), 0)
    ImageDraw.Draw(img).text((0, 0), ch, font=font, fill=255)
    px = img.load()
    rows = [[1 if px[x, y] > 127 else 0 for x in range(SIZE)] for y in range(SIZE)]
    out = []
    for half in (0, 1):
        for c in range(16):
            b = 0
            for r in range(8):
                if rows[half * 8 + r][c]:
                    b |= (1 << r)
            out.append(b)
    return out

new_glyph = {ch: glyph_bytes(ch) for ch in ['刘', '嘉', '宸']}
for ch, byts in new_glyph.items():
    print('glyph', ch, 'pixels=', sum(b.bit_count() for b in byts))

# ---------- 2. 解析现有 Hzk 段 ----------
hz_path = os.path.join(BASE, 'HARDWARE', 'OLED', 'oledfont.h')
hz = open(hz_path, 'rb').read().decode('gbk')

m = re.search(r'(?s)(const unsigned char Hzk\[\]\[32\]\s*=\s*\{)(.*?)(\};)', hz)
assert m, 'Hzk segment not found'
body = m.group(2)
rows_txt = re.findall(r'\{([0-9A-Fa-fx,]+)\}', body)
labels = re.findall(r'/\*"([^"]+)",(\d+)\*/', body)
assert len(rows_txt) == 50, 'expect 50 rows, got %d' % len(rows_txt)
assert len(labels) == 25, 'expect 25 labels, got %d' % len(labels)

# 现有每字 32 字节: 上行 16 + 下行 16
old_chars = []
for no in range(25):
    up = [int(x, 16) for x in rows_txt[2 * no].split(',')]
    dn = [int(x, 16) for x in rows_txt[2 * no + 1].split(',')]
    old_chars.append((labels[no][0], up + dn))

# 新顺序: 0~21 保留, 22 刘, 23 嘉, 24 ℃ 保留, 25 宸
new_order = []
for no in range(22):                      # 0..21
    new_order.append((labels[no][0], old_chars[no][1]))
new_order.append(('刘', new_glyph['刘']))
new_order.append(('嘉', new_glyph['嘉']))
new_order.append(('℃', old_chars[24][1]))   # 24 保留原 ℃
new_order.append(('宸', new_glyph['宸']))

def fmt(byts):
    return '{' + ','.join('0x%02X' % b for b in byts) + '}'

lines = ['const unsigned char Hzk[][32] = {']
for no, (lab, byts) in enumerate(new_order):
    lines.append('    %s,/*"%s",%d*/' % (fmt(byts[0:16]), lab, no))
    lines.append('    %s,' % fmt(byts[16:32]))
lines.append('};')
new_seg = '\r\n'.join(lines) + '\r\n'

hz2 = hz[:m.start()] + new_seg + hz[m.end():]
open(hz_path, 'wb').write(hz2.encode('gbk'))
print('oledfont.h Hzk rebuilt: %d chars' % len(new_order))

# ---------- 3. oled.h 宏定义 (GBK, 精确替换并断言命中) ----------
oh_path = os.path.join(BASE, 'HARDWARE', 'OLED', 'oled.h')
oh = open(oh_path, 'rb').read().decode('gbk')

def rep_once(text, old, new):
    assert text.count(old) == 1, 'expect 1 match: %s' % old
    return text.replace(old, new)

oh = rep_once(oh, '#define CH_CHEN     22  //陈', '#define CH_LIU     22  //刘')
oh = rep_once(oh, '#define CH_HUA      23  //桦', '#define CH_JIA     23  //嘉')
oh = rep_once(oh, '#define CH_CELSIUS  24  //℃',
              '#define CH_CELSIUS  24  //℃\r\n#define CH_CHEN     25  //宸')
open(oh_path, 'wb').write(oh.encode('gbk'))
print('oled.h macros updated')

# ---------- 4. main.c (UTF-8, CRLF) ----------
mc_path = os.path.join(BASE, 'USER', 'main.c')
mc = open(mc_path, 'rb').read().decode('utf-8')

# 学号行: 保持学号不变, 仅把行尾注释改为"学号"
mc, n1 = re.subn(r'OLED_ShowString\(32, 0, "632407030219", 16\);/\*.*?\*/',
                 'OLED_ShowString(32, 0, "632407030219", 16);/* 学号 */', mc)
assert n1 == 1, 'student id line not matched: %d' % n1

mc, n2 = re.subn(r'OLED_ShowCHinese\(68, 2, CH_LIU\);.*',
                'OLED_ShowCHinese(68, 2, CH_LIU);           /* 刘 */', mc)
mc, n3 = re.subn(r'OLED_ShowCHinese\(84, 2, CH_JIA\);.*',
                'OLED_ShowCHinese(84, 2, CH_JIA);           /* 嘉 */', mc)
mc, n4 = re.subn(r'OLED_ShowCHinese\(100, 2, CH_CHEN\);.*',
                'OLED_ShowCHinese(100, 2, CH_CHEN);         /* 宸 */', mc)
assert (n2, n3, n4) == (1, 1, 1), 'name lines: %d,%d,%d' % (n2, n3, n4)

open(mc_path, 'wb').write(mc.encode('utf-8'))
print('main.c name lines updated')
