# -*- coding: utf-8 -*-
"""static_check.py — 静态验证: 括号配平 / 宏定义 / 字库条目 / 函数引用"""
import os, re

base = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'

def read_gbk(rel):
    p = os.path.join(base, rel)
    return open(p, 'rb').read().decode('gbk', errors='replace')

def strip_comments_and_strings(text):
    """移除注释与字符串字面量, 便于检查括号与标识符"""
    out = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c == '/' and i + 1 < n and text[i+1] == '/':
            j = text.find('\n', i)
            i = j if j != -1 else n
        elif c == '/' and i + 1 < n and text[i+1] == '*':
            j = text.find('*/', i + 2)
            i = j + 2 if j != -1 else n
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                if text[i] == '\\': i += 1
                i += 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and text[i] != "'":
                if text[i] == '\\': i += 1
                i += 1
            i += 1
        else:
            out.append(c)
            i += 1
    return ''.join(out)

def balance(text, name):
    ok = True
    for op, cl in [('{','}'), ('(',')'), ('[',']')]:
        if text.count(op) != text.count(cl):
            print('  !! %s: %s=%d %s=%d' % (name, op, text.count(op), cl, text.count(cl)))
            ok = False
    return ok

files = ['USER/main.c', 'HARDWARE/OLED/oled.c', 'HARDWARE/OLED/oled.h',
         'HARDWARE/OLED/oledfont.h', 'HARDWARE/AHT20/aht20.c', 'HARDWARE/AHT20/aht20.h']
print('== 括号配平 ==')
texts = {}
for f in files:
    texts[f] = read_gbk(f)
    st = strip_comments_and_strings(texts[f])
    if balance(st, f):
        print('  ok:', f)

print('\n== Hzk 字库校验 (厂商布局: 每字 2 行 x 16 字节, 声明 Hzk[][32]) ==')
hz = texts['HARDWARE/OLED/oledfont.h']
m = re.search(r'(?s)const unsigned char Hzk\[\]\[32\]\s*=\s*\{(.*?)\};', hz)
if not m:
    print('  !! Hzk table not found')
else:
    entries = re.findall(r'\{([0-9A-Fa-fx,]+)\}', m.group(1))
    print('  rows:', len(entries), '(期望 52 = 26 字 x 2)')
    bad = [i for i, e in enumerate(entries) if len(e.split(',')) != 16]
    print('  bad-size rows:', bad if bad else 'none')
    # 每条开头注释字符
    names = re.findall(r'/\*"([^"]+)"', m.group(1))
    print('  char labels:', names)
    print('  labels count:', len(names))

print('\n== main.c 使用的 CH_ 宏是否都在 oled.h 定义 ==')
ol = texts['HARDWARE/OLED/oled.h']
ch_defs = set(re.findall(r'#define\s+(CH_[A-Z0-9_]+)\s+\d+', ol))
print('  defined:', sorted(ch_defs))
used = set(re.findall(r'\bCH_[A-Z0-9_]+\b', texts['USER/main.c']))
missing = used - ch_defs
print('  used in main.c:', sorted(used))
print('  missing:', missing if missing else 'none')

print('\n== 函数引用一致性 (main.c/aht20.c 调用的函数在头文件中有原型) ==')
main_src = texts['USER/main.c']
calls_main = set(re.findall(r'\b(OLED_[A-Za-z0-9_]+|AHT20_[A-Za-z0-9_]+|delay_[a-z0-9_]+|NVIC_Configuration)\s*\(', main_src))
print('  main.c calls:', sorted(calls_main))
aht_src = texts['HARDWARE/AHT20/aht20.c']
calls_aht = set(re.findall(r'\b(AHT20_IIC_[A-Za-z0-9_]+|AHT20_SDA_[A-Za-z0-9_]+|AHT20_SCL_[A-Za-z0-9_]+|AHT20_IIC_Delay)\s*\(', aht_src))
print('  aht20.c internal calls:', sorted(calls_aht))

print('\n== oled.c 新函数是否在 oled.h 有原型 ==')
protos = ' '.join(re.findall(r'void\s+(OLED_[A-Za-z0-9_]+)\s*\(', ol))
newfns = ['OLED_Scroll_Stop', 'OLED_Scroll_Horizontal', 'OLED_Scroll_Vertical',
          'OLED_FB_Clear', 'OLED_FB_Flush', 'OLED_FB_ShowChar', 'OLED_FB_ShowCHinese']
for f in newfns:
    print('  %-24s proto:%s def:%s' % (f, f in protos, f in texts['HARDWARE/OLED/oled.c']))

print('\n== aht20.c/h 一致性 ==')
print('  Init declared:', 'AHT20_Init' in texts['HARDWARE/AHT20/aht20.h'])
print('  Read declared:', 'AHT20_Read_Temp_Humi' in texts['HARDWARE/AHT20/aht20.h'])
print('  Init defined:', 'u8 AHT20_Init' in aht_src)
print('  Read defined:', 'u8 AHT20_Read_Temp_Humi' in aht_src)

print('\n== F8X16/F6x8 字库仍在 ==')
print('  F8X16:', 'F8X16[]' in hz or 'F8X16' in hz)
print('  F6x8:', 'F6x8[][]' in hz or 'F6x8' in hz)
