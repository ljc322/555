//////////////////////////////////////////////////////////////////////////////////
// ???: main.c
// ??  : OLED(SSD1306, IIC) + AHT20 ????????? (STM32F103C8)
// ??  : 1) ???????
//         2) ?? AHT20 ?????
//         3) ???????(????/???? + ?????)
// ??  : OLED  SCL=PA5  SDA=PA7  (3.3V)
//         AHT20 SCL=PB6  SDA=PB7  (3.3V)
//////////////////////////////////////////////////////////////////////////////////
#include "delay.h"
#include "sys.h"
#include "oled.h"
#include "aht20.h"
/* ???: "Hello, ?????????????205???!" */
#define MARQUEE_ASCII_LEN   7                /* "Hello, " 7 ???, 56px */
#define MARQUEE_CN_LEN      16               /* 16 ???, 256px */
#define MARQUEE_TAIL_LEN    4                /* "205!" 4 ???, 32px */
#define MARQUEE_WIDTH       (56 + 256 + 32)  /* ???? 344px */
void OLED_ShowFloat(u8 x, u8 y, float f, u8 int_len, u8 dec_len, u8 size);
void OLED_Marquee_Draw(s16 x, u8 y);
void OLED_ShowHex(u8 x, u8 y, u8 v, u8 size);
int main(void)
{
    u8   k, err;
    float temp = 0, humi = 0;
    s16  xoff;
    delay_init();               /* ????? */
    NVIC_Configuration();       /* NVIC ???? */
    OLED_Init();                /* OLED ??? */
    OLED_Clear();               /* ?? */
    AHT20_Init();
    /* ========== IIC ??? (?????, 8 ?) ========== */
    {
        u8 scl, sda, ack;
        OLED_Clear();
        OLED_ShowString(0, 0, "IIC SELF TEST", 16);
        AHT20_SelfTest(&scl, &sda, &ack);
        OLED_ShowString(0, 2, "SCL:", 16);
        OLED_ShowChar(48, 2, scl ? '1' : '0', 16);
        OLED_ShowString(64, 2, "SDA:", 16);
        OLED_ShowChar(112, 2, sda ? '1' : '0', 16);
        OLED_ShowString(0, 4, "ADDR:", 16);
        if (ack == 0) OLED_ShowString(64, 4, "ACK-OK", 16);
        else          OLED_ShowString(64, 4, "NO-ACK", 16);
        OLED_ShowString(0, 6, "PB6-SCL PB7-SDA", 16);
        delay_ms(8000);
    }
    while (1)
    {
        /* ========== ? 1 ?: ?? + ?? ========== */
        OLED_Clear();
        OLED_ShowCHinese(0, 0, CH_XUE);            /* ? */
        OLED_ShowCHinese(16, 0, CH_HAO);           /* ? */
        OLED_ShowString(32, 0, "632407030219", 16);/* ?? */
        OLED_ShowCHinese(28, 2, CH_XING);          /* ? */
        OLED_ShowCHinese(44, 2, CH_MING);          /* ? */
        OLED_ShowChar(60, 2, ':', 16);
        OLED_ShowCHinese(68, 2, CH_LIU);           /* ? */
        OLED_ShowCHinese(84, 2, CH_JIA);           /* ? */
        OLED_ShowCHinese(100, 2, CH_CHEN);         /* ? */
        OLED_ShowString(8, 4, "0.96 OLED DEMO", 16);
        delay_ms(3000);
        /* ========== ? 2 ?: AHT20 ??? (????) ========== */
        for (k = 0; k < 8; k++)
        {
            OLED_Clear();
            err = AHT20_Read_Temp_Humi(&temp, &humi);
            /* ??: ??:xx.x? */
            OLED_ShowCHinese(16, 0, CH_WEN);
            OLED_ShowCHinese(32, 0, CH_DU);
            OLED_ShowChar(48, 0, ':', 16);
            if (err == 0)
            {
                OLED_ShowFloat(56, 0, temp, 2, 1, 16);
                OLED_ShowCHinese(88, 0, CH_CELSIUS);   /* ? */
            }
            else { OLED_ShowString(40, 0, "ST:", 16); OLED_ShowHex(72, 0, AHT20_dbg_buf[0], 16); }
            /* ??: ??:xx.x% */
            OLED_ShowCHinese(16, 2, CH_HUMID);
            OLED_ShowCHinese(32, 2, CH_DU);
            OLED_ShowChar(48, 2, ':', 16);
            if (err == 0)
            {
                OLED_ShowFloat(56, 2, humi, 2, 1, 16);
                OLED_ShowChar(88, 2, '%', 16);
            }
            else { OLED_ShowString(40, 2, "ST:", 16); OLED_ShowHex(72, 2, AHT20_dbg_buf[0], 16); }
            OLED_ShowString(16, 4, "AHT20 SENSOR", 16);
            OLED_ShowString(20, 6, "IIC PB6-PB7", 16);
            delay_ms(1000);
        }
        /* ========== ? 3 ?: ?????? (?????) ========== */
        OLED_Clear();
        /* ? 1 ?: Hello,???? */
        OLED_ShowString(0, 0, "Hello,", 16);
        OLED_ShowCHinese(48, 0, CH_HUAN);   /* ? */
        OLED_ShowCHinese(64, 0, CH_YING);   /* ? */
        OLED_ShowCHinese(80, 0, CH_LAI);    /* ? */
        OLED_ShowCHinese(96, 0, CH_DAO);    /* ? */
        /* ? 2 ?: ?????? */
        OLED_ShowCHinese(0, 2, CH_CHONG);   /* ? */
        OLED_ShowCHinese(16, 2, CH_QING);   /* ? */
        OLED_ShowCHinese(32, 2, CH_JIAO);   /* ? */
        OLED_ShowCHinese(48, 2, CH_TONG);   /* ? */
        OLED_ShowCHinese(64, 2, CH_DA);     /* ? */
        OLED_ShowCHinese(80, 2, CH_XUE);    /* ? */
        /* ? 3 ?: ???205?? */
        OLED_ShowCHinese(0, 4, CH_WU);      /* ? */
        OLED_ShowCHinese(16, 4, CH_LIAN);   /* ? */
        OLED_ShowCHinese(32, 4, CH_WANG);   /* ? */
        OLED_ShowString(48, 4, "205", 16);
        OLED_ShowCHinese(72, 4, CH_SHI);    /* ? */
        OLED_ShowCHinese(88, 4, CH_XUN);    /* ? */
        /* ? 4 ?: ?!AHT20 DEMO */
        OLED_ShowCHinese(0, 6, CH_ROOM);    /* ? */
        OLED_ShowChar(16, 6, '!', 16);
        OLED_ShowString(24, 6, "AHT20 DEMO", 16);
        OLED_Scroll_Horizontal(0, 0, 7, 0x00);  /* ??????,??,5??? */
        delay_ms(5000);
        OLED_Scroll_Stop();                     /* ???? */
        /* ========== ? 4 ?: ????+???? (?????) ========== */
        OLED_Scroll_Vertical(1, 0, 7, 0x00, 0, 64); /* ????,?? 64 ? */
        delay_ms(5000);
        OLED_Scroll_Stop();
        /* ========== ? 5 ?: ????? (?????????) ========== */
        for (xoff = 0; xoff <= (s16)(MARQUEE_WIDTH - 128); xoff += 4)
        {
            OLED_FB_Clear();
            OLED_Marquee_Draw(-xoff, 2);        /* ??? 2 ?(16~31?),???? */
            OLED_FB_Flush();                    /* ???? */
            delay_ms(20);
        }
        delay_ms(1500);
    }
}
/* ???????: -12.3 / 25.3 ? */
void OLED_ShowFloat(u8 x, u8 y, float f, u8 int_len, u8 dec_len, u8 size)
{
    u32 ip, dp;
    if (f < 0) { OLED_ShowChar(x, y, '-', size); x += size / 2; f = -f; }
    ip = (u32)f;
    dp = (u32)((f - ip) * 10.0f + 0.5f);        /* ?? 1 ???,???? */
    OLED_ShowNum(x, y, ip, int_len, size);
    x += int_len * (size / 2);
    OLED_ShowChar(x, y, '.', size);
    x += size / 2;
    OLED_ShowNum(x, y, dp, dec_len, size);
}
/* ??????????? x ??????? (??????) */
void OLED_Marquee_Draw(s16 x, u8 y)
{
    u8 i;
    s16 xx = x;
    const u8 ascii[MARQUEE_ASCII_LEN] = {'H', 'e', 'l', 'l', 'o', ',', ' '};
    const u8 cn[MARQUEE_CN_LEN] = {CH_HUAN, CH_YING, CH_LAI, CH_DAO,
                                   CH_CHONG, CH_QING, CH_JIAO, CH_TONG,
                                   CH_DA, CH_XUE, CH_WU, CH_LIAN,
                                   CH_WANG, CH_SHI, CH_XUN, CH_ROOM};
    const u8 tail[MARQUEE_TAIL_LEN] = {'2', '0', '5', '!'};
    for (i = 0; i < MARQUEE_ASCII_LEN; i++) { OLED_FB_ShowChar(xx, y, ascii[i], 16); xx += 8; }
    for (i = 0; i < MARQUEE_CN_LEN; i++)    { OLED_FB_ShowCHinese(xx, y, cn[i]); xx += 16; }
    for (i = 0; i < MARQUEE_TAIL_LEN; i++)  { OLED_FB_ShowChar(xx, y, tail[i], 16); xx += 8; }
}
/* ??: ?????????? (??2??) */
void OLED_ShowHex(u8 x, u8 y, u8 v, u8 size)
{
    const u8 hex[] = "0123456789ABCDEF";
    OLED_ShowChar(x, y, hex[v >> 4], size);
    OLED_ShowChar(x + size / 2, y, hex[v & 0x0F], size);
}
