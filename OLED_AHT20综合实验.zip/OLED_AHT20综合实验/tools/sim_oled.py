# -*- coding: utf-8 -*-
"""sim_oled.py — 用工程内真实字库数据模拟 OLED(128x64) 显示, 验证各屏布局与效果
读取 HARDWARE/OLED/oledfont.h 中的 F8X16/F6x8/Hzk, 模拟 OLED_ShowChar/ShowCHinese/
ShowString/帧缓冲, 渲染出第1屏、第2屏、第3屏文本与跑马灯若干帧 -> PNG
"""
import os, re
from PIL import Image

BASE = r'C:\Users\ljc1\Desktop\OLED_AHT20综合实验'
FONT_PATH = os.path.join(BASE, 'HARDWARE', 'OLED', 'oledfont.h')

text = open(FONT_PATH, 'rb').read().decode('gbk', errors='replace')

def strip_c(s):
    s = re.sub(r'//[^\r\n]*', '', s)      # 先删行注释
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)  # 再删块注释
    return s

TEXT = strip_c(text)

def parse_array(name, row_len=0):
    start = TEXT.find(name)
    i = TEXT.index('{', start)
    depth = 0
    j = i
    while j < len(TEXT):
        if TEXT[j] == '{': depth += 1
        elif TEXT[j] == '}':
            depth -= 1
            if depth == 0: break
        j += 1
    body = TEXT[i+1:j]
    toks = [int(x, 16) for x in re.findall(r'0[xX][0-9A-Fa-f]+', body)]
    if row_len:
        return [toks[k*row_len:(k+1)*row_len] for k in range(len(toks)//row_len)]
    return toks

F8X16 = parse_array('F8X16', 16)
F6x8  = parse_array('F6x8', 6)
Hzk   = parse_array('Hzk', 16)   # 厂商布局: 每字 2 行 x 16 字节
print('F8X16:', len(F8X16), 'F6x8:', len(F6x8), 'Hzk rows:', len(Hzk))

# ---------------- 模拟 128x64 OLED, 8 页 ---------------- 
class OLED:
    def __init__(self):
        self.fb = [[0]*128 for _ in range(8)]
    def clear(self):
        self.fb = [[0]*128 for _ in range(8)]
    def put(self, page, col, byte):
        if 0 <= page < 8 and 0 <= col < 128:
            self.fb[page][col] = byte
    def show_char(self, x, y, ch, size):      # y 为页号
        c = ord(ch) - 32
        if size == 16:
            row = F8X16[c]
            for i in range(8):
                self.put(y, x+i, row[i])
                self.put(y+1, x+i, row[i+8])
        else:
            for i in range(6):
                self.put(y, x+i, F6x8[c][i])
    def show_str(self, x, y, s, size):
        for ch in s:
            self.show_char(x, y, ch, size)
            x += 8
            if x > 120:
                x = 0; y += 2
    def show_cn(self, x, y, no):              # y 为页号; Hzk[2*no]=上半, [2*no+1]=下半
        up = Hzk[2*no]
        dn = Hzk[2*no+1]
        for i in range(16):
            self.put(y, x+i, up[i])
            self.put(y+1, x+i, dn[i])
    def show_num(self, x, y, num, length, size):
        for t in range(length):
            d = (num // (10 ** (length - t - 1))) % 10
            self.show_char(x + (size//2)*t, y, chr(ord('0')+d), size)
    def show_float(self, x, y, f, ilen, dlen, size):
        if f < 0:
            self.show_char(x, y, '-', size); x += size//2; f = -f
        ip = int(f)
        dp = int((f - ip) * 10 + 0.5)
        self.show_num(x, y, ip, ilen, size)
        x += ilen*(size//2)
        self.show_char(x, y, '.', size)
        x += size//2
        self.show_num(x, y, dp, dlen, size)
    def fb_show_char(self, x, y, ch, size):   # 帧缓冲版 (x 可为负), y 为像素行
        c = ord(ch) - 32
        if size == 16:
            row = F8X16[c]
            for i in range(8):
                cx = x + i
                if cx < 0 or cx > 127: continue
                self.fb[y//8][cx] = row[i]
                self.fb[y//8+1][cx] = row[i+8]
        else:
            for i in range(6):
                cx = x + i
                if cx < 0 or cx > 127: continue
                self.fb[y//8][cx] = F6x8[c][i]
    def fb_show_cn(self, x, y, no):
        up = Hzk[2*no]
        dn = Hzk[2*no+1]
        for i in range(16):
            cx = x + i
            if cx < 0 or cx > 127: continue
            self.fb[y//8][cx] = up[i]
            self.fb[y//8+1][cx] = dn[i]
    def render(self, scale=3):
        img = Image.new('RGB', (128*scale, 64*scale), (0,0,0))
        px = img.load()
        for p in range(8):
            for c in range(128):
                b = self.fb[p][c]
                for r in range(8):
                    if b & (1 << r):
                        yy = p*8 + r
                        for dx in range(scale):
                            for dy in range(scale):
                                px[c*scale+dx, yy*scale+dy] = (0, 160, 0)
        return img

# CH 索引
CH = {'XUE':0,'HAO':1,'XING':2,'MING':3,'WEN':4,'DU':5,'HUMID':6,'HUAN':7,'YING':8,
      'LAI':9,'DAO':10,'CHONG':11,'QING':12,'JIAO':13,'TONG':14,'DA':15,'WU':16,
      'LIAN':17,'WANG':18,'SHI':19,'XUN':20,'ROOM':21,'LIU':22,'JIA':23,
      'CELSIUS':24,'CHEN':25}
def cn(k): return CH[k]

# ============ 第1屏: 学号姓名 ============
o = OLED()
o.show_cn(0, 0, cn('XUE')); o.show_cn(16, 0, cn('HAO'))
o.show_str(32, 0, '632407030219', 16)
o.show_cn(28, 2, cn('XING')); o.show_cn(44, 2, cn('MING'))
o.show_char(60, 2, ':', 16); o.show_cn(68, 2, cn('LIU')); o.show_cn(84, 2, cn('JIA')); o.show_cn(100, 2, cn('CHEN'))
o.show_str(8, 4, '0.96 OLED DEMO', 16)
o.render().save(os.path.join(BASE, 'tools', 'sim_screen1.png'))

# ============ 第2屏: 温湿度 ============
o = OLED()
temp, humi = 25.3, 60.2
o.show_cn(16, 0, cn('WEN')); o.show_cn(32, 0, cn('DU')); o.show_char(48, 0, ':', 16)
o.show_float(56, 0, temp, 2, 1, 16); o.show_cn(88, 0, cn('CELSIUS'))
o.show_cn(16, 2, cn('HUMID')); o.show_cn(32, 2, cn('DU')); o.show_char(48, 2, ':', 16)
o.show_float(56, 2, humi, 2, 1, 16); o.show_char(88, 2, '%', 16)
o.show_str(16, 4, 'AHT20 SENSOR', 16)
o.show_str(20, 6, 'IIC PB6-PB7', 16)
o.render().save(os.path.join(BASE, 'tools', 'sim_screen2.png'))

# ============ 第3屏: 硬件滚动文本 ============
o = OLED()
o.show_str(0, 0, 'Hello,', 16)
o.show_cn(48, 0, cn('HUAN')); o.show_cn(64, 0, cn('YING')); o.show_cn(80, 0, cn('LAI')); o.show_cn(96, 0, cn('DAO'))
o.show_cn(0, 2, cn('CHONG')); o.show_cn(16, 2, cn('QING')); o.show_cn(32, 2, cn('JIAO')); o.show_cn(48, 2, cn('TONG')); o.show_cn(64, 2, cn('DA')); o.show_cn(80, 2, cn('XUE'))
o.show_cn(0, 4, cn('WU')); o.show_cn(16, 4, cn('LIAN')); o.show_cn(32, 4, cn('WANG'))
o.show_str(48, 4, '205', 16)
o.show_cn(72, 4, cn('SHI')); o.show_cn(88, 4, cn('XUN'))
o.show_cn(0, 6, cn('ROOM')); o.show_char(16, 6, '!', 16); o.show_str(24, 6, 'AHT20 DEMO', 16)
o.render().save(os.path.join(BASE, 'tools', 'sim_screen3.png'))

# ============ 第5屏: 跑马灯若干帧 (y=2 即像素16行) ============
ascii_txt = 'Hello, '
cn_list = ['HUAN','YING','LAI','DAO','CHONG','QING','JIAO','TONG','DA','XUE','WU','LIAN','WANG','SHI','XUN','ROOM']
tail = '205!'
def marquee(o, xoff):
    x = -xoff
    for ch in ascii_txt:
        o.fb_show_char(x, 16, ch, 16); x += 8
    for k in cn_list:
        o.fb_show_cn(x, 16, cn(k)); x += 16
    for ch in tail:
        o.fb_show_char(x, 16, ch, 16); x += 8
for idx, xoff in enumerate([0, 60, 128, 216]):
    o = OLED()
    marquee(o, xoff)
    o.render().save(os.path.join(BASE, 'tools', 'sim_marquee_%d.png' % xoff))
print('sim images saved')
