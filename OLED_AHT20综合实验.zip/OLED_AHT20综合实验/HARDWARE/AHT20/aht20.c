  #include "aht20.h"
#include "delay.h"
#include "stm32f10x.h"

/* ==================== AHT20 ���� IIC (PB6=SCL, PB7=SDA) ==================== */
#define AHT20_SCL_H()   PBout(6) = 1
#define AHT20_SCL_L()   PBout(6) = 0
#define AHT20_SDA_H()   PBout(7) = 1
#define AHT20_SDA_L()   PBout(7) = 0
#define AHT20_SDA_READ()  PBin(7)          /* �� SDA ��ƽ */

#define AHT20_ADDR_W    0x70               /* 7 λ��ַ 0x38, д��ַ�ֽ� */
#define AHT20_ADDR_R    0x71               /* ����ַ�ֽ� */

u8 AHT20_dbg_buf[6];                            /* ����: ���һ�ζ��ص� 6 �ֽ� */

/* SDA ��������/���ģʽ�л� (PB7 ��Ӧ CRL �� bit28~31) */
static void AHT20_SDA_Input(void)
{
    GPIOB->CRL &= ~((u32)0x0F << 28);
    GPIOB->CRL |=  (0x04 << 28);           /* ���븡�� */
}
static void AHT20_SDA_Output(void)
{
    GPIOB->CRL &= ~((u32)0x0F << 28);
    GPIOB->CRL |=  (0x03 << 28);           /* ������� 50MHz */
}

/* ��������ʱ, ���� IIC ���� (2us -> Լ 250kHz) */
static void AHT20_IIC_Delay(void)
{
    delay_us(2);
}

/* IIC ��ʼ: SCL �ߵ�ƽ�ڼ� SDA �����½��� */
static void AHT20_IIC_Start(void)
{
    AHT20_SDA_Output();
    AHT20_SDA_H();
    AHT20_SCL_H();
    AHT20_IIC_Delay();
    AHT20_SDA_L();
    AHT20_IIC_Delay();
    AHT20_SCL_L();
    AHT20_IIC_Delay();
}

/* IIC ֹͣ: SCL �ߵ�ƽ�ڼ� SDA ���������� */
static void AHT20_IIC_Stop(void)
{
    AHT20_SDA_Output();
    AHT20_SDA_L();
    AHT20_SCL_H();
    AHT20_IIC_Delay();
    AHT20_SDA_H();
    AHT20_IIC_Delay();
}

/* дһ���ֽ� (MSB ��ǰ), �ͷ� SDA ������һ�� ACK ʱ��(�����Ӧ��) */
static void AHT20_IIC_WriteByte(u8 dat)
{
    u8 i;
    AHT20_SDA_Output();
    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80) AHT20_SDA_H();
        else            AHT20_SDA_L();
        dat <<= 1;
        AHT20_SCL_H();
        AHT20_IIC_Delay();
        AHT20_SCL_L();
        AHT20_IIC_Delay();
    }
    AHT20_SDA_H();                          /* �ͷ� SDA, �ôӻ�����Ӧ�� */
    AHT20_SCL_H();
    AHT20_IIC_Delay();
    AHT20_SCL_L();
    AHT20_IIC_Delay();
}

/* ��һ���ֽ�: ack=1 ����Ӧ��, ack=0 ���ͷ�Ӧ��(���һλ) */
static u8 AHT20_IIC_ReadByte(u8 ack)
{
    u8 i, dat = 0;
    AHT20_SDA_Input();
    for (i = 0; i < 8; i++)
    {
        AHT20_SCL_H();
        AHT20_IIC_Delay();
        dat <<= 1;
        if (AHT20_SDA_READ()) dat |= 0x01;
        AHT20_SCL_L();
        AHT20_IIC_Delay();
    }
    AHT20_SDA_Output();
    if (ack) AHT20_SDA_L();
    else     AHT20_SDA_H();
    AHT20_SCL_H();
    AHT20_IIC_Delay();
    AHT20_SCL_L();
    AHT20_IIC_Delay();
    AHT20_SDA_H();
    return dat;
}

/* ==================== AHT20 ҵ���� ==================== */

/* ��ʼ��: �������� + �ϵ��ʼ������ 0xBE 0x08 0x00 */
u8 AHT20_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);

    delay_ms(100);                          /* �ϵ��ȶ�ʱ�� */
    AHT20_IIC_Start();
    AHT20_IIC_WriteByte(AHT20_ADDR_W);      /* �ӻ���ַ(д) */
    AHT20_IIC_WriteByte(0xBE);              /* ��ʼ�������� */
    AHT20_IIC_WriteByte(0x08);
    AHT20_IIC_WriteByte(0x00);
    AHT20_IIC_Stop();
    delay_ms(10);
    return 0;
}

/* ����һ�β�������ȡ��ʪ��
 * AHT20 ���ݸ�ʽ:
 *   �������� 0xAC 0x33 0x00, Լ 80ms ��� 6 �ֽ�:
 *   [0]״̬ [1][2]ʪ�ȸ�/�� [3]ʪ�ȵ�4λ|�¶ȸ�4λ [4][5]�¶���/��
 *   ʪ�� = 20bit / 2^20 * 100 %
 *   �¶� = 20bit / 2^20 * 200 - 50 ��
 */
u8 AHT20_Read_Temp_Humi(float *temp, float *humi)
{
    u8 buf[6] = {0, 0, 0, 0, 0, 0};
    u32 raw_h = 0, raw_t = 0;
    u8 i;

    /* 1. �������� */
    AHT20_IIC_Start();
    AHT20_IIC_WriteByte(AHT20_ADDR_W);
    AHT20_IIC_WriteByte(0xAC);
    AHT20_IIC_WriteByte(0x33);
    AHT20_IIC_WriteByte(0x00);
    AHT20_IIC_Stop();

    delay_ms(80);                           /* �ȴ�������� */

    /* 2. ��ȡ 6 �ֽ� (���һλ��Ӧ��) */
    AHT20_IIC_Start();
    AHT20_IIC_WriteByte(AHT20_ADDR_R);
    for (i = 0; i < 6; i++)
        buf[i] = AHT20_IIC_ReadByte(i < 5 ? 1 : 0);
    AHT20_IIC_Stop();

    /* 3. ���� */
    if (buf[0] & 0x80)  { for (i = 0; i < 6; i++) AHT20_dbg_buf[i] = buf[i]; return 1; }            /* bit7: æ */
    if (!(buf[0] & 0x08)) { for (i = 0; i < 6; i++) AHT20_dbg_buf[i] = buf[i]; return 2; }         /* bit3: δУ׼ */

    raw_h = ((u32)buf[1] << 12) | ((u32)buf[2] << 4) | ((u32)buf[3] >> 4);
    raw_t = (((u32)buf[3] & 0x0F) << 16) | ((u32)buf[4] << 8) | (u32)buf[5];

    *humi = (float)raw_h * 100.0f / 1048576.0f;   /* / 2^20 */
    *temp = (float)raw_t * 200.0f / 1048576.0f - 50.0f;
    return 0;
}

/* ==================== IIC �Լ� (���Ǳ����) ==================== */

static u8 AHT20_IIC_WriteByteAck(u8 dat)
{
    u8 i, ack;
    AHT20_SDA_Output();
    for (i = 0; i < 8; i++)
    {
        if (dat & 0x80) AHT20_SDA_H();
        else            AHT20_SDA_L();
        dat <<= 1;
        AHT20_SCL_H();
        AHT20_IIC_Delay();
        AHT20_SCL_L();
        AHT20_IIC_Delay();
    }
    AHT20_SDA_Input();
    AHT20_SCL_H();
    AHT20_IIC_Delay();
    ack = AHT20_SDA_READ();
    AHT20_SCL_L();
    AHT20_IIC_Delay();
    AHT20_SDA_Output();
    AHT20_SDA_H();
    return ack;
}

u8 AHT20_SelfTest(u8 *scl, u8 *sda, u8 *ack)
{
    GPIO_InitTypeDef gpio;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    gpio.GPIO_Pin   = GPIO_Pin_6 | GPIO_Pin_7;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpio);
    delay_ms(2);
    *scl = PBin(6) ? 1 : 0;
    *sda = PBin(7) ? 1 : 0;
    gpio.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &gpio);
    GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);
    delay_ms(2);
    AHT20_IIC_Start();
    *ack = AHT20_IIC_WriteByteAck(AHT20_ADDR_W);
    AHT20_IIC_Stop();
    return 0;
}
