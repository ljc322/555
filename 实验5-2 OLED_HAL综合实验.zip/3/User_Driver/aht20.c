#include "aht20.h"
#include "i2c.h"

#define AHT20_ADDR 0x70

void AHT20_Init(void)
{
    uint8_t cmd[3] = {0xBE, 0x08, 0x00};
    HAL_Delay(40);
    HAL_I2C_Mem_Write(&hi2c1, AHT20_ADDR, 0x00, I2C_MEMADD_SIZE_8BIT, cmd, 3, 100);
    HAL_Delay(10);
}

uint8_t AHT20_Read(float *temp, float *humi)
{
    uint8_t cmd[3] = {0xAC, 0x33, 0x00};
    uint8_t buf[6];

    HAL_I2C_Mem_Write(&hi2c1, AHT20_ADDR, 0x00, I2C_MEMADD_SIZE_8BIT, cmd, 3, 100);
    HAL_Delay(80);

    if (HAL_I2C_Mem_Read(&hi2c1, AHT20_ADDR, 0x00, I2C_MEMADD_SIZE_8BIT, buf, 6, 100) != HAL_OK)
    {
        return 0;
    }

    if ((buf[0] & 0x80) != 0)
    {
        return 0;
    }

    uint32_t raw_h = ((uint32_t)(buf[1]) << 12) | ((uint32_t)(buf[2]) << 4) | (buf[3] >> 4);
    uint32_t raw_t = (((uint32_t)(buf[3] & 0x0F)) << 16) | ((uint32_t)(buf[4]) << 8) | buf[5];

    *humi = raw_h * 100.0f / (1 << 20);
    *temp = raw_t * 200.0f / (1 << 20) - 50.0f;
    return 1;
}
