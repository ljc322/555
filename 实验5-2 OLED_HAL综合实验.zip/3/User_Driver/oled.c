#include "oled.h"
#include "i2c.h"

static uint8_t OLED_I2C_Addr = 0x78;

void OLED_WriteCmd(uint8_t cmd)
{
    uint8_t buf[2];
    buf[0] = 0x00;
    buf[1] = cmd;
    HAL_I2C_Mem_Write(&hi2c1, OLED_I2C_Addr, 0x00, I2C_MEMADD_SIZE_8BIT, buf, 2, 100);
}

void OLED_WriteData(uint8_t data)
{
    uint8_t buf[2];
    buf[0] = 0x40;
    buf[1] = data;
    HAL_I2C_Mem_Write(&hi2c1, OLED_I2C_Addr, 0x00, I2C_MEMADD_SIZE_8BIT, buf, 2, 100);
}

void OLED_Init(void)
{
    HAL_Delay(100);
    OLED_WriteCmd(0xAE);
    OLED_WriteCmd(0xD5);
    OLED_WriteCmd(0x80);
    OLED_WriteCmd(0xA8);
    OLED_WriteCmd(0x3F);
    OLED_WriteCmd(0xD3);
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0x40);
    OLED_WriteCmd(0xA1);
    OLED_WriteCmd(0xC8);
    OLED_WriteCmd(0xDA);
    OLED_WriteCmd(0x12);
    OLED_WriteCmd(0x81);
    OLED_WriteCmd(0xCF);
    OLED_WriteCmd(0xD9);
    OLED_WriteCmd(0xF1);
    OLED_WriteCmd(0xDB);
    OLED_WriteCmd(0x30);
    OLED_WriteCmd(0xA4);
    OLED_WriteCmd(0xA6);
    OLED_WriteCmd(0xAF);
    OLED_Clear();
}

void OLED_Clear(void)
{
    uint8_t y, x;
    for (y = 0; y < 8; y++)
    {
        OLED_WriteCmd(0xB0 + y);
        OLED_WriteCmd(0x00);
        OLED_WriteCmd(0x10);
        for (x = 0; x < 128; x++)
        {
            OLED_WriteData(0x00);
        }
    }
}

void OLED_ShowChar(uint8_t x, uint8_t y, uint8_t chr)
{
    // 极简版本：如需完整字库，可以替换为带字库的版本
    OLED_ShowString(x, y, (char *)&chr);
}

void OLED_ShowString(uint8_t x, uint8_t y, char *str)
{
    OLED_WriteCmd(0xB0 + y);
    OLED_WriteCmd(((x & 0xF0) >> 4) | 0x10);
    OLED_WriteCmd(x & 0x0F);
    while (*str)
    {
        OLED_WriteData(*str++);
    }
}
