#ifndef __AHT20_H
#define __AHT20_H

#include "main.h"

void AHT20_Init(void);
uint8_t AHT20_Read(float* temp, float* humi);

#endif
